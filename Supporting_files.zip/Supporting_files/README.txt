These are files generated in the study "Evolutionary dynamics of the LTR-retrotransposon crapaud in the Podospora anserina species complex and the interaction with repeat-induced point mutations" by Westerberg et al.

The following are short descriptions of each file:


"all_podospora_finalrepeatcounts.out" = interspersed repeat statistics generated from RepeatMasker using the previously published PodoTE1.0 repeat library.


"All_SSNstats_and_GC.txt" = The network statistics from Cytoscape from the "Crapaud_LTRs_allAgainstAll_v2_80i_80c.net" network. Also includes whether the copies are rogue/non-rogue as "Outside" or "Inside"


"Crapaud_full_onlyint_aligned.fasta.treefile" = the inner element phylogeny treefile generated from  IQTree.


"Crapaud_full_onlyint_allAgainstAll_V2_80i_70c.net" = The sequence similarity network file of the inner region (excluding LTRs) of the 150 full copies identified in the species complex


"Crapaud_full_onlyinternal_aligned.fasta" = The MAFFT alignment of the 150 full copies (excluding LTRs)


"Crapaud_full_withLTRs_unaligned_fixedpositions" = The unaligned MSA of the 150 full copies (excluding LTRs"


"Crapaud_LTRs_allAgainstAll_v2_80i_80c.net" = The sequence similarity network file of the 1305 curated LTRs identified in the species complex.


"Crapaud_LTRs_Solos_and_full_fixed_aligned.fasta" = The MAFFT alignment of the 1305 LTRs.


"Crapaud_LTRs_Solos_and_full_fixed_aligned.fasta.treefile" = The ML phylogeny treefile of the 1305 LTRs generated from IQtree


"PodoTE-2.00.lib" = The new repeat library with the centroid sequences of the crapaud LTR subfamilies included.


"RMcountV3_Subfamilies_V2_noLTR11or12_counts_250filter.out" = The RepeatMasker count of LTRs in the genomes, generated using the "RM_retriever_V3_submission.py" script from the RepeatMasker output of the crapaud LTR subfamilies. 
